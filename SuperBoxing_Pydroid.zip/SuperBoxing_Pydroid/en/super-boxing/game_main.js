// ============================================================
// Super Boxing - Game Logic
// يستخدم الصور الموجودة في media/
// ============================================================

(function() {
    'use strict';
    
    // ========================================================
    // إعدادات اللعبة
    // ========================================================
    var GAME = {
        WIDTH: 480,
        HEIGHT: 640,
        FPS: 60,
        MAX_HEALTH: 100,
        ROUND_TIME: 60,
        MAX_ROUNDS: 3,
        FIGHTER_SPEED: 4,
        PUNCH_DAMAGE: 8,
        BLOCK_REDUCTION: 0.3,
        PUNCH_COOLDOWN: 30, // frames
        AI_DIFFICULTY: 0.7,
    };
    
    // ========================================================
    // تحميل الصور
    // ========================================================
    var Images = {};
    var imageCache = {};
    
    function loadImage(src) {
        if (imageCache[src]) return imageCache[src];
        var img = new Image();
        img.src = src;
        imageCache[src] = img;
        return img;
    }
    
    // تحميل كل الصور
    function preloadImages() {
        // الحلبة
        for (var i = 0; i <= 35; i++) {
            var num = ('0000' + i).slice(-4);
            Images['ring_' + i] = loadImage(
                'media/graphics/sprites/boxing_ring/frame_' + num + '.png'
            );
        }
        
        // صور القائمة
        Images.bg_ring = loadImage('media/graphics/sprites/start_menu/ring.png');
        Images.bg_audience = loadImage('media/graphics/sprites/start_menu/audience.png');
        Images.bg_foreground = loadImage('media/graphics/sprites/start_menu/foreground.png');
        Images.title = loadImage('media/graphics/sprites/start_menu/title.png');
        Images.menu_player = loadImage('media/graphics/sprites/start_menu/player.png');
        Images.menu_enemy = loadImage('media/graphics/sprites/start_menu/enemy.png');
        
        // نتيجة
        Images.result = loadImage('media/graphics/sprites/result.jpg');
        
        // أزرار
        Images.buttons = loadImage('media/graphics/sprites/button.png');
        Images.btn_more = loadImage('media/graphics/sprites/btn_more_games.png');
        
        console.log('✅ تم تحميل جميع الصور');
    }
    
    // ========================================================
    // اللاعب
    // ========================================================
    function Fighter(name, x, y, isPlayer) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = 80;
        this.height = 150;
        this.health = GAME.MAX_HEALTH;
        this.energy = 100;
        this.isPlayer = isPlayer;
        this.isBlocking = false;
        this.isPunching = false;
        this.punchCooldown = 0;
        this.state = 'idle'; // idle, walking, punching_left, punching_right, blocking, hurt, knocked_out
        this.facing = isPlayer ? 1 : -1; // 1 = right, -1 = left
        this.animFrame = 0;
        this.animTimer = 0;
        this.velocity = 0;
        this.targetX = x;
        
        // تحميل صور الملاكم
        this.sprites = {};
        var prefix = isPlayer ? 'white_fighter_action/player' : 'black_fighter_action/enemy';
        var actions = ['breath', 'left', 'right', 'block', 'hurt'];
        
        for (var a = 0; a < actions.length; a++) {
            this.sprites[actions[a]] = [];
            var maxFrames = 8;
            if (actions[a] === 'hurt') maxFrames = 11;
            if (actions[a] === 'block') maxFrames = 7;
            
            for (var f = 0; f < maxFrames; f++) {
                var num;
                if (actions[a] === 'breath' && !isPlayer) {
                    num = ('0000' + (f * 2 + 3)).slice(-4);
                } else if (actions[a] === 'hurt') {
                    num = ('0000' + (f * 2 + 20)).slice(-4);
                } else {
                    num = ('0000' + (f * 2 + 20 - (isPlayer ? 0 : 0))).slice(-4);
                }
                
                var path = 'media/graphics/sprites/' + prefix + '/' + actions[a] + '/frame_' + num + '.png';
                // تبسيط: استخدام أول إطار فقط للعرض
                if (f === 0) {
                    this.sprites[actions[a]].push(loadImage(path));
                }
            }
        }
    }
    
    Fighter.prototype.update = function(enemy) {
        // تبريد اللكمات
        if (this.punchCooldown > 0) {
            this.punchCooldown--;
            if (this.punchCooldown === 0) {
                this.state = 'idle';
                this.isPunching = false;
            }
        }
        
        // تجديد الطاقة
        if (this.energy < 100) {
            this.energy += 0.1;
        }
        
        // حركة سلسة
        if (Math.abs(this.x - this.targetX) > 2) {
            this.x += (this.targetX - this.x) * 0.2;
            this.state = 'walking';
        } else if (this.state === 'walking') {
            this.state = 'idle';
        }
        
        // حدود الحلبة
        this.x = Math.max(20, Math.min(GAME.WIDTH - this.width - 20, this.x));
        
        // تحديث الأنيميشن
        this.animTimer++;
        if (this.animTimer > 10) {
            this.animTimer = 0;
            this.animFrame = (this.animFrame + 1) % 4;
        }
    };
    
    Fighter.prototype.punch = function(type) {
        if (this.isPunching || this.energy < 10) return false;
        
        this.isPunching = true;
        this.punchCooldown = GAME.PUNCH_COOLDOWN;
        this.energy -= 10;
        this.state = type === 'left' ? 'punching_left' : 'punching_right';
        
        // تأثير حركة للأمام
        this.targetX += this.facing * 20;
        
        return true;
    };
    
    Fighter.prototype.block = function() {
        if (this.energy < 5) return;
        this.isBlocking = true;
        this.state = 'blocking';
        this.energy -= 5;
        
        var self = this;
        setTimeout(function() {
            self.isBlocking = false;
            if (self.state === 'blocking') self.state = 'idle';
        }, 400);
    };
    
    Fighter.prototype.takeDamage = function(damage) {
        if (this.isBlocking) {
            damage *= GAME.BLOCK_REDUCTION;
        }
        
        this.health -= damage;
        this.state = 'hurt';
        
        var self = this;
        setTimeout(function() {
            if (self.state === 'hurt' && self.health > 0) self.state = 'idle';
        }, 300);
        
        return damage;
    };
    
    Fighter.prototype.draw = function(ctx) {
        ctx.save();
        
        // انعكاس حسب الاتجاه
        if (this.facing === -1) {
            ctx.translate(this.x + this.width, 0);
            ctx.scale(-1, 1);
            ctx.drawImage(this.getCurrentSprite(), 0, this.y, this.width, this.height);
        } else {
            ctx.drawImage(this.getCurrentSprite(), this.x, this.y, this.width, this.height);
        }
        
        ctx.restore();
        
        // رسم شريط الطاقة
        this.drawHealthBar(ctx);
    };
    
    Fighter.prototype.getCurrentSprite = function() {
        var action = 'breath';
        switch (this.state) {
            case 'punching_left': action = 'left'; break;
            case 'punching_right': action = 'right'; break;
            case 'blocking': action = 'block'; break;
            case 'hurt': action = 'hurt'; break;
            default: action = 'breath'; break;
        }
        return this.sprites[action] && this.sprites[action][0] || this.sprites['breath'][0];
    };
    
    Fighter.prototype.drawHealthBar = function(ctx) {
        var barX = this.isPlayer ? 10 : GAME.WIDTH - 130;
        var barY = 10;
        var barW = 120;
        var barH = 18;
        
        // خلفية
        ctx.fillStyle = '#333';
        ctx.fillRect(barX, barY, barW, barH);
        
        // صحة
        var healthPercent = this.health / GAME.MAX_HEALTH;
        var color = healthPercent > 0.5 ? '#4CAF50' : healthPercent > 0.25 ? '#FF9800' : '#F44336';
        ctx.fillStyle = color;
        ctx.fillRect(barX + 1, barY + 1, (barW - 2) * healthPercent, barH - 2);
        
        // طاقة
        ctx.fillStyle = '#2196F3';
        ctx.fillRect(barX + 1, barY + barH + 2, (barW - 2) * (this.energy / 100), 6);
        
        // اسم
        ctx.fillStyle = '#FFF';
        ctx.font = 'bold 11px Arial';
        ctx.textAlign = this.isPlayer ? 'left' : 'right';
        ctx.fillText(this.name, barX, barY - 5);
        ctx.textAlign = 'left';
    };
    
    // ========================================================
    // الذكاء الاصطناعي
    // ========================================================
    function AI(fighter) {
        this.fighter = fighter;
        this.timer = 0;
        this.currentAction = 'idle';
    }
    
    AI.prototype.update = function(player) {
        this.timer--;
        if (this.timer > 0) return;
        
        var f = this.fighter;
        var distance = Math.abs(f.x - player.x);
        var rand = Math.random();
        
        if (distance < 80) {
            // قريب جداً
            if (rand < 0.4 && f.energy > 15) {
                // لكمة
                var type = Math.random() > 0.5 ? 'left' : 'right';
                f.punch(type);
                if (this.hitsPlayer(f, player)) {
                    player.takeDamage(GAME.PUNCH_DAMAGE);
                }
            } else if (rand < 0.8) {
                f.block();
            } else {
                f.targetX += f.facing * -50;
            }
        } else if (distance < 200) {
            if (rand < 0.6) {
                f.targetX = player.x;
            } else {
                var type = Math.random() > 0.5 ? 'left' : 'right';
                f.punch(type);
            }
        } else {
            f.targetX = player.x;
        }
        
        this.timer = 20 + Math.random() * 40;
    };
    
    AI.prototype.hitsPlayer = function(fighter, player) {
        var dx = Math.abs(fighter.x - player.x);
        return dx < 100;
    };
    
    // ========================================================
    // اللعبة الرئيسية
    // ========================================================
    var game = {
        canvas: null,
        ctx: null,
        state: 'menu', // menu, playing, roundEnd, result
        player: null,
        enemy: null,
        enemyAI: null,
        round: 1,
        timeLeft: GAME.ROUND_TIME,
        timer: null,
        ringFrame: 0,
        ringAnimTimer: 0,
        keys: {},
        touchActive: false,
        touchStartX: 0,
        touchStartY: 0,
        
        init: function() {
            this.canvas = document.getElementById('canvas');
            if (!this.canvas) {
                console.error('❌ Canvas not found!');
                return;
            }
            
            this.ctx = this.canvas.getContext('2d');
            this.canvas.width = GAME.WIDTH;
            this.canvas.height = GAME.HEIGHT;
            
            // تحميل الصور
            preloadImages();
            
            // إنشاء المقاتلين
            this.player = new Fighter('أنت', 120, GAME.HEIGHT - 280, true);
            this.enemy = new Fighter('الخصم', GAME.WIDTH - 200, GAME.HEIGHT - 280, false);
            this.enemyAI = new AI(this.enemy);
            
            // ربط الأحداث
            this.bindEvents();
            
            // بدء الحلقة
            this.loop();
            
            console.log('🥊 Super Boxing Ready!');
        },
        
        bindEvents: function() {
            var self = this;
            
            // لوحة المفاتيح
            document.addEventListener('keydown', function(e) {
                self.keys[e.key] = true;
                self.handleInput();
            });
            
            document.addEventListener('keyup', function(e) {
                self.keys[e.key] = false;
            });
            
            // اللمس
            this.canvas.addEventListener('touchstart', function(e) {
                e.preventDefault();
                if (self.state === 'menu') {
                    self.startGame();
                    return;
                }
                if (self.state === 'result') {
                    self.resetGame();
                    return;
                }
                
                var touch = e.touches[0];
                var rect = self.canvas.getBoundingClientRect();
                var scaleX = GAME.WIDTH / rect.width;
                var scaleY = GAME.HEIGHT / rect.height;
                var x = (touch.clientX - rect.left) * scaleX;
                var y = (touch.clientY - rect.top) * scaleY;
                
                self.touchActive = true;
                self.touchStartX = x;
                self.touchStartY = y;
                self.handleTouch(x, y);
            });
            
            // النقر بالماوس
            this.canvas.addEventListener('click', function(e) {
                if (self.state === 'menu') {
                    self.startGame();
                    return;
                }
                if (self.state === 'result') {
                    self.resetGame();
                    return;
                }
                
                var rect = self.canvas.getBoundingClientRect();
                var scaleX = GAME.WIDTH / rect.width;
                var scaleY = GAME.HEIGHT / rect.height;
                var x = (e.clientX - rect.left) * scaleX;
                var y = (e.clientY - rect.top) * scaleY;
                
                self.handleTouch(x, y);
            });
        },
        
        handleInput: function() {
            if (this.state !== 'playing') return;
            
            var p = this.player;
            
            // حركة
            if (this.keys['ArrowLeft'] || this.keys['a']) {
                p.targetX -= GAME.FIGHTER_SPEED * 3;
            }
            if (this.keys['ArrowRight'] || this.keys['d']) {
                p.targetX += GAME.FIGHTER_SPEED * 3;
            }
            
            // لكمات
            if (this.keys['q'] || this.keys['z']) {
                if (p.punch('left') && this.checkHit(p, this.enemy)) {
                    this.enemy.takeDamage(GAME.PUNCH_DAMAGE);
                }
            }
            if (this.keys['e'] || this.keys['x']) {
                if (p.punch('right') && this.checkHit(p, this.enemy)) {
                    this.enemy.takeDamage(GAME.PUNCH_DAMAGE);
                }
            }
            
            // صد
            if (this.keys[' '] || this.keys['Shift']) {
                p.block();
            }
        },
        
        handleTouch: function(x, y) {
            if (this.state !== 'playing') return;
            
            var p = this.player;
            
            if (y > GAME.HEIGHT * 0.6) {
                // أسفل الشاشة - أزرار التحكم
                if (x < GAME.WIDTH / 3) {
                    // لكمة يسار
                    if (p.punch('left') && this.checkHit(p, this.enemy)) {
                        this.enemy.takeDamage(GAME.PUNCH_DAMAGE);
                    }
                } else if (x > GAME.WIDTH * 2 / 3) {
                    // لكمة يمين
                    if (p.punch('right') && this.checkHit(p, this.enemy)) {
                        this.enemy.takeDamage(GAME.PUNCH_DAMAGE);
                    }
                } else {
                    // صد
                    p.block();
                }
            } else {
                // حركة
                p.targetX = x - p.width / 2;
            }
        },
        
        checkHit: function(attacker, defender) {
            var dx = Math.abs(attacker.x - defender.x);
            return dx < 120;
        },
        
        startGame: function() {
            console.log('🔔 بدء المباراة!');
            this.state = 'playing';
            this.round = 1;
            this.player.health = GAME.MAX_HEALTH;
            this.enemy.health = GAME.MAX_HEALTH;
            this.timeLeft = GAME.ROUND_TIME;
            
            if (this.timer) clearInterval(this.timer);
            var self = this;
            this.timer = setInterval(function() {
                if (self.state === 'playing') {
                    self.timeLeft--;
                    if (self.timeLeft <= 0) {
                        self.endRound();
                    }
                }
            }, 1000);
        },
        
        resetGame: function() {
            this.state = 'menu';
            this.player.health = GAME.MAX_HEALTH;
            this.enemy.health = GAME.MAX_HEALTH;
            this.player.energy = 100;
            this.enemy.energy = 100;
            this.round = 1;
            this.timeLeft = GAME.ROUND_TIME;
            if (this.timer) clearInterval(this.timer);
        },
        
        endRound: function() {
            this.round++;
            if (this.round > GAME.MAX_ROUNDS) {
                this.endMatch();
            } else {
                this.timeLeft = GAME.ROUND_TIME;
                this.player.energy = 100;
                this.enemy.energy = 100;
            }
        },
        
        endMatch: function() {
            this.state = 'result';
            if (this.timer) clearInterval(this.timer);
        },
        
        update: function() {
            if (this.state === 'playing') {
                this.player.update();
                this.enemyAI.update(this.player);
                this.enemy.update();
                
                // تحقق من الفوز/الخسارة
                if (this.player.health <= 0) {
                    this.state = 'result';
                }
                if (this.enemy.health <= 0) {
                    this.state = 'result';
                }
            }
            
            // تحديث أنيميشن الحلبة
            this.ringAnimTimer++;
            if (this.ringAnimTimer > 5) {
                this.ringAnimTimer = 0;
                this.ringFrame = (this.ringFrame + 1) % 36;
            }
        },
        
        draw: function() {
            var ctx = this.ctx;
            
            // مسح الشاشة
            ctx.fillStyle = '#1a1a2e';
            ctx.fillRect(0, 0, GAME.WIDTH, GAME.HEIGHT);
            
            if (this.state === 'menu') {
                this.drawMenu(ctx);
            } else if (this.state === 'playing' || this.state === 'roundEnd') {
                this.drawArena(ctx);
                this.player.draw(ctx);
                this.enemy.draw(ctx);
                this.drawTimer(ctx);
                this.drawRoundInfo(ctx);
                this.drawControls(ctx);
            } else if (this.state === 'result') {
                this.drawArena(ctx);
                this.player.draw(ctx);
                this.enemy.draw(ctx);
                this.drawResult(ctx);
            }
        },
        
        drawMenu: function(ctx) {
            // خلفية
            if (Images.bg_ring) {
                ctx.drawImage(Images.bg_ring, 0, 0, GAME.WIDTH, GAME.HEIGHT);
            }
            if (Images.bg_audience) {
                ctx.drawImage(Images.bg_audience, 0, 0, GAME.WIDTH, GAME.HEIGHT);
            }
            
            // عنوان
            if (Images.title) {
                ctx.drawImage(Images.title, 
                    GAME.WIDTH / 2 - 120, 50, 240, 80);
            }
            
            // الملاكمين
            if (Images.menu_player) {
                ctx.drawImage(Images.menu_player, 
                    50, GAME.HEIGHT / 2 - 100, 150, 200);
            }
            if (Images.menu_enemy) {
                ctx.drawImage(Images.menu_enemy,
                    GAME.WIDTH - 200, GAME.HEIGHT / 2 - 100, 150, 200);
            }
            
            // نص
            ctx.fillStyle = '#FFD700';
            ctx.font = 'bold 24px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('🥊 Super Boxing 🥊', GAME.WIDTH / 2, 30);
            
            ctx.fillStyle = '#FFF';
            ctx.font = '18px Arial';
            var alpha = 0.5 + Math.sin(Date.now() / 500) * 0.5;
            ctx.globalAlpha = alpha;
            ctx.fillText('اضغط للبدء', GAME.WIDTH / 2, GAME.HEIGHT - 50);
            ctx.globalAlpha = 1;
            ctx.textAlign = 'left';
        },
        
        drawArena: function(ctx) {
            // الحلبة
            if (Images['ring_0']) {
                var frameKey = 'ring_' + this.ringFrame;
                ctx.drawImage(Images[frameKey] || Images['ring_0'], 
                    0, 0, GAME.WIDTH, GAME.HEIGHT);
            }
        },
        
        drawTimer: function(ctx) {
            var minutes = Math.floor(this.timeLeft / 60);
            var seconds = this.timeLeft % 60;
            var timeStr = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            
            ctx.fillStyle = this.timeLeft <= 10 ? '#F44336' : '#FFF';
            ctx.font = 'bold 28px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(timeStr, GAME.WIDTH / 2, 40);
            ctx.textAlign = 'left';
        },
        
        drawRoundInfo: function(ctx) {
            ctx.fillStyle = '#FFD700';
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('الجولة ' + this.round + ' / ' + GAME.MAX_ROUNDS,
                GAME.WIDTH / 2, 65);
            ctx.textAlign = 'left';
        },
        
        drawControls: function(ctx) {
            // أزرار تحكم للموبايل
            var y = GAME.HEIGHT - 80;
            
            // زر يسار
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.beginPath();
            ctx.arc(70, y + 30, 35, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#FFF';
            ctx.font = 'bold 14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('👊', 70, y + 35);
            
            // زر يمين
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.beginPath();
            ctx.arc(GAME.WIDTH - 70, y + 30, 35, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillText('👊', GAME.WIDTH - 70, y + 35);
            
            // زر صد
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.beginPath();
            ctx.arc(GAME.WIDTH / 2, y + 30, 35, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillText('🛡️', GAME.WIDTH / 2, y + 35);
            
            ctx.textAlign = 'left';
        },
        
        drawResult: function(ctx) {
            // خلفية شفافة
            ctx.fillStyle = 'rgba(0,0,0,0.7)';
            ctx.fillRect(0, 0, GAME.WIDTH, GAME.HEIGHT);
            
            // نتيجة
            var text, color;
            if (this.player.health <= 0) {
                text = '😢 خسرت!';
                color = '#F44336';
            } else if (this.enemy.health <= 0) {
                text = '🎉 فزت!';
                color = '#FFD700';
            } else {
                text = '🤝 تعادل!';
                color = '#FFF';
            }
            
            ctx.fillStyle = color;
            ctx.font = 'bold 40px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(text, GAME.WIDTH / 2, GAME.HEIGHT / 2 - 20);
            
            ctx.fillStyle = '#FFF';
            ctx.font = '18px Arial';
            ctx.fillText('اضغط للمحاولة مرة أخرى',
                GAME.WIDTH / 2, GAME.HEIGHT / 2 + 40);
            ctx.textAlign = 'left';
        },
        
        loop: function() {
            game.update();
            game.draw();
            requestAnimationFrame(game.loop);
        }
    };
    
    // بدء اللعبة عند تحميل الصفحة
    window.addEventListener('load', function() {
        game.init();
    });
    
    // تصدير للاستخدام الخارجي
    window.SuperBoxing = game;
    
})();